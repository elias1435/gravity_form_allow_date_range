  jQuery.noConflict();
 jQuery(function() {

  jQuery('input[id="drpf"]').daterangepicker({
     autoUpdateInput: false,
    locale: {
       cancelLabel: 'Clear',
    },
    minDate: moment().startOf('day'),
    changeMonth: false,
    changeYear: false
  });
jQuery('input[id="drpf"]').on('apply.daterangepicker', function(ev, picker) {
      jQuery(this).val(picker.startDate.format('DD/MM/YYYY') + ' - ' + picker.endDate.format('DD/MM/YYYY'));
  });

  jQuery('input[id="drpf"]').on('cancel.daterangepicker', function(ev, picker) {
     jQuery(this).val('');
  });
});
 
