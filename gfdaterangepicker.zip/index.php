<?php
/* Silence is gold */