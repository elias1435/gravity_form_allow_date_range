<?php
// uninstall Plugin
// if(!defined(WP_UNINSTALL_PLUGIN))
// {
//     die;
// }

//  delete_option( 'my_plugin_option' );
